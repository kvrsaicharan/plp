import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from '../components/home.component';
import Login from '../components/login.component';
// import Register from '../components/Register';
import AddAddvertisements from '../components/addAddvertisement.component';
import List from '../components/List';
import ProductsList from '../components/productsList.component'
import Account from '../components/signInAccount.component';
import DisplayProduct from '../components/displayProduct.component';


const NotFound = () => {
    return (<div>
        <h4>The Page You Are Requested Is Not Found. Error:404</h4>
    </div>
    );
}

class Routes extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() {
        return (
            <Router>
                <Switch>
                    <Route exact path='/' component={Home} />
                    <Route exact path='/user/login' component={Login} />
                    <Route exact path='/user/register' component={Register} />
                    <Route exact path='/post' component={AddAddvertisements} />
                    <Route exact path='/myaccount' component={Account} />
                    <Route exact path='/item/:id' component={DisplayProduct} />
                    <Route exact path='/list' component={List}/>
                
                    <Route exact path='/productsList/:category' component={ProductsList} />
                    <Route exact path='/cities/:city' component={ProductsList} />


                    <Route exact path='*' component={NotFound} />

                </Switch>
            </Router>


        );
    }
}

export default Routes;

