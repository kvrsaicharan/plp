export const category = [
   
    {category:'Boys', path:require('../assests/images/images (1).jpg')},
    {category:'Girls', path:require('../assests/images/images (4).jpg')},
    {category:'Kids', path:require('../assests/images/images (2).jpg')},
    {category:'Furniture', path:require('../assests/images/furnature4.jpg')},
      
]