import React, { Component } from 'react';
import Header from './header.component';
import Footer from './footer.component';

class About extends Component {

    render() {
        return (

            <div style={{ backgroundImage: "url(http://theartinspiration.com/wp-content/uploads/2013/08/hd-wallpaper-nature09.jpg)", backgroundRepeat: "no-repeat", backgroundSize: "cover" }}>
                <Header />
                <div><h1>
                    <ul className="text-center text-light">
                            <b >This Web-site is used to Post Your Advertisment for free ...</b>
                            <li>Men ware</li>
                            <li>Ladies Garnments</li>
                            <li>Gadgets</li>
                            <li>Furniture</li>
                            <li>Kid's Ware</li>

                    </ul></h1>
                    <br/><br/><br/><br/><br/><br/>
                    <br/><br/><br/>
                    <Footer />
                </div>
            </div>

        )

    }

}

export default About;