import React from 'react';
import Header from './header.component'
//import '../static/css/submit.css';
import { category } from '../config/category';
//import { province, cities } from '../config/location';
import axios from 'axios';
import NotificationSystem from 'react-notification-system';
import App from '../App';
import Footer from './footer.component';

const _userId = JSON.parse(localStorage.getItem('UserObject'));

class AddAddvertisements extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            allcategory: category,
          
            selectindex: undefined,
            img0: '',
            img1: '',
            img2: '',
            img3: ''


        };
        

    }
    onchange = (event) => {
        event.preventDefault();

        switch (event.target.name) {

            case 'img0':
                this.setState({ img0: event.target.files[0].name })
                break;
            case 'img1':
                this.setState({ img1: event.target.files[0].name })
                break;
            case 'img2':
                this.setState({ img2: event.target.files[0].name })
                break;
            case 'img3':
                this.setState({ img3: event.target.files[0].name })
                break;
            default:
                break;
        }


    }
    //this will make you in contact with home after log in.

    componentWillMount() {
        if (_userId === null) {

            window.location = '/user/login';
        }
    }
    // Notification

    _notificationSystem = null

    _addNotification = (level, msg) => {
        
        this._notificationSystem.addNotification({
            message: msg,
            level: level
        });
    }

    componentDidMount() {
        this._notificationSystem = this.refs.notificationSystem;
    }
    // Axios Request
    postAdd = (e) => {
        e.preventDefault();
        var form = document.getElementById('addform')
        var formData = new FormData(form);
        if (this.props.match.path === '/post') {


            axios.post('http://localhost:5000/item/ads', formData).then(res => {
                console.log(res.data);

                this._addNotification("success", "Your ad successfully upload.");
                window.location = '/';
            })
                .catch(err => {
                    console.log(err.response);
                    this._addNotification("error", "You have an error in your form please check and resubmit again.")
                });
        } else {
            let path = this.props.match.params.id;
            axios.put('http://localhost:5000/item/ads/update/?id=' + path, formData).then(res => {
                console.log(res.data);

                this._addNotification("success", "Your ad successfully updated.");
                window.location = '/';
            })
                .catch(err => {
                    console.log(err.response);
                    this._addNotification("error", "You have an error in your form please check and resubmit again.")
                });

        }

    }

    // Selected Category against result 
    selectCategory = () => {
        var selectBox = document.getElementById("selectcate");
        var selectedValue = selectBox.options[selectBox.selectedIndex].value;
        if (selectedValue === 'Boys' || selectedValue === 'Girls') {
            this.setState({
                condition: false
            });
        } else {
            this.setState({
                condition: true
            })
        }


    }

    // Selected province index
    selectedindex = () => {
        var selectBox = document.getElementById("selectBox");
        var selectedValue = selectBox.options[selectBox.selectedIndex].value;

        this.setState({
            selectindex: selectedValue,
        });

    }

    //title, categoryname, price, condition, description,
    // photos, name, phone, selectprovince, selectcity
    render() {
        const { selectindex, allcities, allprovince, allcategory
        } = this.state;
        return (
            <div>
            <div  className="row" >
                <div id="container" 
                style={{ backgroundImage: "url(https://www.barraques.cat/pngfile/big/0-7755_nature-pier-bridge-d-river-water-sunset-night.jpg)", backgroundRepeat: "no-repeat", backgroundSize: "cover" }}>
                    <Header posting={true} />
                    <br/>
                    <div  className="container">
                    <div id="subbox">
                        <h1 className="text-center text-info">Post Your Advertisement</h1>
                        <div id="submitform">
                            <form id="addform" encType="multipart/form-data" onSubmit={this.postAdd}>
                                <input type="hidden" name="_userId" defaultValue={_userId._id} />
                                <label>
                                    <b>Title Of Your Addvertisement</b>
                                <span style={{ color: 'red' }}>*</span>
                                </label>
                                <input type="text" id="title"
                                    className="form-control" name="title" required maxLength='70' />
                                <small id="title" className="form-text text-muted">Maximum 120 characters</small>
                                <br /><br />
                                <label>
                                    <b>Category</b>
                                    <span style={{ color: 'red' }}>*</span>
                                    </label>
                                <select id="selectcate"
                                    onChange={this.selectCategory}

                                    className="form-control" required name="category">
                                    <option value='' >Select Category</option>
                                    
                                    {allcategory.map((item) => {
                                        return (
                                            <option value={item.cateegory} key={item.category}>{item.category}</option>
                                        );
                                    })}


                                </select>

                                <hr />                             
                                <label>
                                    <b>Add Description</b>
                                    <span style={{ color: 'red' }}>*</span>
                                    </label>
                                <textarea cols={60} rows={4}

                                    className="form-control" name="description" placeholder="Including the brand, model, age, KM's and any other accessories" required>
                                </textarea>
                                 <br /> <br />

                                <label>
                                    <b>For Addvertisement :</b>
                                <span style={{ color: 'red' }}>*</span>
                                </label>
                               
                                <div className="custom-file mb-3" >

                                    <input type="file" className="custom-file-input" 
                                    onChange={this.onchange} name="img0" id="img0" required />
                                    <label htmlFor="img0" className="custom-file-label" >
                                    {this.state.img0}</label>
                                </div>
                                <label>
                                    <b>upload products :</b>
                                <span style={{ color: 'red' }}>*</span>
                                </label>

                                <div className="custom-file mb-3" >
                                    <input type="file" className="custom-file-input" onChange={this.onchange} name="img1" id="img1" required />
                                    <label htmlFor="img1" className="custom-file-label" >{this.state.img1}</label>
                                </div>
                                <div className="custom-file mb-3" >
                                    <input type="file" className="custom-file-input" onChange={this.onchange} name="img2" id="img2" required />
                                    <label htmlFor="img2" className="custom-file-label" >{this.state.img2}</label>
                                </div>
                                <div className="custom-file mb-3" >
                                    <input type="file" className="custom-file-input" onChange={this.onchange} name="img3" id="img3" required />
                                    <label htmlFor="img3" className="custom-file-label" >{this.state.img3}</label>
                                </div>
                                

                                <hr />
                                <label><b>Name</b><span style={{ color: 'red' }}>*</span></label>
                                <input type="text" id="name"

                                    name="name" className="form-control" required /><br />



                                <label><b>Phone number</b><span style={{ color: 'red' }}>*</span></label>
                                <input type="number" name="phone" className="form-control" 
                                placeholder="+91" required pattern="[6-9][0-9]{0,9}" maxLength="10"/><br />
                                <hr />

                                 <label><b>Status</b><span style={{ color: 'red' }}>*</span></label>
                                <input type="text" id="status"


                                    name="status" className="form-control"  required /><br />
                                <hr />
                                {/* <label><b>location</b><span style={{ color: 'red' }}>*</span></label>
                                <select id="selectBox" name="location" onChange={this.selectedindex} className="form-control" required >
                                    <option value={null}>Choose Location</option>
                                    {allprovince.map((item) => {
                                        return (
                                            <option value={item} key={item}>{item}</option>
                                        );

                                    })

                                    }
                                </select><br /> */}

                                {/* {(selectindex === undefined ? '' :
                                    <div>
                                        <label><b>Cities</b><span style={{ color: 'red' }}>*</span></label>

                                        <select className="form-control" id="selectcity"

                                            name="city" required>
                                            <option value=''>Choose Province</option>

                                            {selectindex !== undefined && allcities[selectindex].map((item) => {


                                                return (
                                                    <option value={item.city} key={item.city}>{item.city}</option>
                                                )
                                            })}
                                        </select>
                                    </div>
                                )} */}
                                
                                <input type="submit" name="submit" value="Submit" className="btn btn-outline-success btn-lg" />
                            </form>
                        </div>

                    </div>


                </div>
               
                <NotificationSystem ref="notificationSystem" />
               
            </div>
            </div>

          
</div>
        );
    }
}

export default AddAddvertisements;



